﻿using UnityEngine;
using System.Collections;

public class endMsgGui : MonoBehaviour {

	public GUISkin customSkin3;
	public int final_score;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnGUI(){
		GUI.skin = customSkin3;
		final_score = carController.score;
		if(GUI.Button (new Rect(0, (Screen.height/2)-150,330,80),"Game Over!!!")){
			//print ("You Clicked The button!!");
			Application.LoadLevel ("title");
		}
		GUI.Label(new Rect(10,10,100,20), "Your Score: "+final_score.ToString());
	}
}
