﻿using UnityEngine;
using System.Collections;

public class carController : MonoBehaviour {
	
	public float carSpeed;
	public static int score = 0;
	Vector3 position;
	public float maxPos = 2.2f;
	void Start () {

		position = transform.position;

	}
	

	void Update () {

			score ++;
			position.x += Input.GetAxis ("Horizontal") * carSpeed * Time.deltaTime;
			position.x = Mathf.Clamp (position.x, -2.2f, 2.2f);
			transform.position = position;

	}

	void OnCollisionEnter2D(Collision2D col){
		
		if (col.gameObject.tag == "Enemy Car") {
			//Destroy (gameObject);
			
			Application.LoadLevel ("end");
	
		}
	}

	


}
