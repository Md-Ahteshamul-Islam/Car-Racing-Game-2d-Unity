﻿using UnityEngine;
using System.Collections;

public class titleGui : MonoBehaviour {

	public GUISkin customSkin;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnGUI(){
		GUI.skin = customSkin;
		if(GUI.Button (new Rect((Screen.width/2)-50, Screen.height/2,90,50),"Play Game")){
			//print ("You Clicked The button!!");
			Application.LoadLevel ("level1");
		}
	}
}
